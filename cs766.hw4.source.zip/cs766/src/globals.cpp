#include "globals.h"

ArgManager* Globals::gArgManager;
int Globals::NUM_FEATS= 200;
int Globals::NUM_ITER = 1000;
int Globals::NUM_PTS = 5;
// Must be odd
int Globals::PILU_WIN_SIZE = 25;
double Globals::PILU_SIGMA = 200;

