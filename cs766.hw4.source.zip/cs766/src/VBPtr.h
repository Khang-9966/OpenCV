#ifndef VBPTR_H
#define VBPTR_H

#include <RefPtr.h>
#include <ValueBlock.h>
typedef RefPtr<ImageMan::ValueBlock> VBPtr;

#endif
