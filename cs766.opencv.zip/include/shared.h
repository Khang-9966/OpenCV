#ifndef _shared_h_
#define _shared_h_


#include <stdlib.h>
#include <stdio.h>
#include <malloc.h>






#endif /* _shared_h_ */