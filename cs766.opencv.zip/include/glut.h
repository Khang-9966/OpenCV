#pragma warning(push)
#pragma warning(disable:4312)
#pragma warning(disable:4311)
#include <gl/glut.h>
#undef min
#undef max
#pragma warning(pop)
