#ifndef _it_shared_h_
#define _it_shared_h_


#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <malloc.h>


#include "ImageTools.h"


#include "util.h"



void    _SetError( int error );
void    _ClearError();


#endif /* _it_shared_h_ */